clear
close all
clc
x = -20 : 0.1 : 20;
identity = ones(1,length(x));
a1 = 0 .* identity;
b1 = 1 .* identity;
a2 = 1 .* identity;
b2 = 2 .* identity;
lx = log(1./2./b1) - abs(x - a1)./ b1 +...
    log(1./2./b2) - abs(x - a2)./ b2;
plot (x, lx)
xlabel('x','FontSize',20);
ylabel('l(x)','FontSize',20);
title('log-likelihood-ratio function','FontSize',20)