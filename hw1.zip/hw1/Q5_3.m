clear
close all
clc

% N = input('Please input N = ');
% n = input('Please input n = ');
% mu = input('Please input mu = ');
% sigma = input('Please input sigma = ');

N = 1000;
n = 3;
mu = 3;
sigma = [0.04 0.20 0.15;
         0.20 0.03 0.10;
         0.15 0.10 0.03];

sigma2 = eye(n);
mu2 = zeros(3,1);
normalized = mvnrnd(mu2, sigma2, N);
A = sym('A', [3 3]);

solve(A * A.' == inv(sigma) , A, A.')

% soppose I have got a from the step above
x = A * normalized + mu;
