clear
close all
clc
%% question 4_2
x = -7: .01: 7;
% mu = 0�� sigma = 1
pd1 = makedist('Normal',0,1);
p1 = pdf(pd1, x);
subplot(1,3,1)
plot(x, p1);
grid minor
xlabel('x')
ylabel('pdf1')
title('\mu = 0, \sigma = 1')

% mu = 1, sigma = sqrt(2)
pd2 = makedist('Normal',1,sqrt(2));
p2 = pdf(pd2, x);
subplot(1,3,2)
plot(x, p2);
grid minor
xlabel('x')
ylabel('pdf2')
title('\mu = 1, \sigma = \surd2')

% decision boundary
p = p1 - p2;
j = 1;
for i = 2 : length(x)
        if p(i)* p(i - 1) < 0
            decision_boundary(j) = x(i);
            j = j + 1;
        end
end
decision_boundary
subplot(1,3,3);
plot(x, p);
xlabel('x')
ylabel('pdf1 - pdf2')
title('pdf1 - pdf2')
grid minor

%% question 4_3
% numerical estimation
point_index_p1 = (p < 0);
point_index_p2 = ~point_index_p1;
minimun_error = sum(p1(point_index_p1) .* .01) + sum(p2(point_index_p2) .* .01)



